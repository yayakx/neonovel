<?php $__env->startSection('main'); ?>
<div class="card col-md-8 ml-auto" style="overflow-y: scroll; height:650px;">    
    <div class="card-body">
        <div class="card-header bg-success text-white row" style="position:sticky; top:0;z-index:50;width:100%">
            <h4 class="text-white col-md" >List Update Novel Terbaru</h4>
            <button class="btn btn-outline-light d-block ml-auto" onclick="location.reload()"><i class="fa fa-sync-alt" aria-hidden="true"></i></button> 
        </div>
            <div class="col-md mt-2">     
                <div class="d-flex justify-content-between text-center">    
                    <p class="card-text col-md-6"><a>Judul</a></p>
                    <p class="card-text col-md-2"><a>Terbit</a></p>
                    <p class="card-text col-md-4"><a>FT</a></p>
                </div>
                <div class="scrolling-pagination">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                <div class="d-flex justify-content-between">                        
                    <p class="card-text col-md-6"><a href="<?php echo e($item->get_permalink()); ?>" target="_blank"><?php echo e($item->get_title()); ?></a></p>
                    <p class="card-text col-md-2"><small><?php echo e($item->get_date('j F Y')); ?></small></p>
                    <p class="card-text col-md-4"><a href="<?php echo e($item->get_base()); ?>"><?php echo e($item->get_base()); ?></a></p>
                </div>             
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </div>                             
            </div>
    </div>
  </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\neonovel\resources\views/listupdate.blade.php ENDPATH**/ ?>